　Tamego Cursor
～たまごカーソル～

マウスカーソルの見た目をたまごにするマウスカーソルです！


＊使い方＊
エクスプローラーを開き、Cドライブ→Windows→Cursors を開き、
tamegocursorフォルダーを、Cursorsフォルダーにコピーします。
★管理者アカウントでサインインしていないとコピーできないです。

次に、Windowsキーを押しながらRを押し、 main.cpl を打ち込みOKを押し、
マウスのプロパティを出します。

上にある「ポインター」タブを選び、
カスタマイズの各項目を、tamegocursorに割り当てます。


ーーーーーーーーーー★設定例★ーーーーーーーーーー
通常の選択			→ Normal.cur
ヘルプの選択			→ Help.cur
バックグラウンドで作業中	→ Background.ani
待ち状態			→ Wait.ani
領域選択			→ Normal.cur
テキスト選択			→ Text.cur
手書き				→ Normal.cur
利用不可			→ No.cur
上下に拡大/縮小			→ MoveNS.cur
左右に拡大/縮小			→ MoveEW.cur
斜めに拡大/縮小１		→ MoveNWSE.cur
斜めに拡大/縮小２		→ MoveNESW.cur
移動				→ Move.cur
代替選択			→ Up.cur
リンクの選択			→ Link.cur
場所の選択			→ Link.cur
人の選択			→ Link.cur
ーーーーーーーーーーーーーーーーーーーーーーーーー


設定できたら、「名前を付けて保存」をします。名前はなんでも良いです。
これでOKまたは適用を押せば、マウスカーソルの見た目がたまごになります！



このマウスカーソルの見た目はYuka0813が作ったものです。
二次配布や改造はやめてね。


by Yuka0813